# A Sample Artist Portfolio
A sample artist portfolio website. Uses HTML, CSS, &amp; JS
